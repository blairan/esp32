from machine import Pin, I2C, ADC, PWM
import ujson, dht, os, binascii, machine
import network, time
import neopixel, re
from umqtttsimple import MQTTClient
import ssd1306, framebuf
try:
    import urequests as requests
except ImportError:
    import requests

ssid = "CTK"
password = "ctk674011"

onedayTopic=b'338/one'
alldayTopic=b'338/allday'
colorTopic=b"338/color"
mqtt_server="49.158.236.151"
server_id=binascii.hexlify(machine.unique_id())

i2c = I2C(scl=Pin(22), sda=Pin(21))
oled = ssd1306.SSD1306_I2C(128, 64, i2c)

def wifiConn(ssid, password):
    wifi = network.WLAN(network.STA_IF)
    wifi.active(True)
    wifi.connect(ssid, password)
    while wifi.isconnected() == False:
        pass
    print("success connected!")
    print("ip :{}".format(wifi.ifconfig()))

wifiConn(ssid, password)

# 即時天氣icons
data = requests.get('https://api.openweathermap.org/data/2.5/weather?q=Taipei,TW&lang=zh_tw&units=metric&appid=f7922c4d99e223e7380d80a7f3db6b64')
jsondatas = ujson.loads(data.text)
print(jsondatas['weather'][0]['icon'])

def checkIcon(n):
    path = "icons/" + n
    try:
        os.stat(path)
        return path
    except:
        return "/icons/na.bin"

def weather_icon():
    global jsondatas
    icon = jsondatas['weather'][0]['icon']
    path = checkIcon(icon + ".bin")
    f = open(path, "rb")
    buf = f.read()
    f.close()
    fb = framebuf.FrameBuffer(bytearray(buf), 48, 48, framebuf.MONO_VLSB)
    oled.blit(fb, 70, 10)

# neoplixel
n, p = 12, 5  # 燈數,#腳位
np = neopixel.NeoPixel(Pin(p), n)

def clear():
    global n, p, np
    for i in range(n):
        np[i] = (0, 0, 0)
        np.write()

def Neopixel():
    global n, p, np
    clear()
    for i in range(n):
        np[i] = (255, 0, 50)
        np.write()

def date_and_time():
    # 日期時間api
    d = requests.get('http://worldtimeapi.org/api/timezone/Asia/Taipei')
    if d.status_code == 200:
        date = ujson.loads(d.text)['datetime'][0:10]
        times = ujson.loads(d.text)['datetime'][11:-16]
        h = int(ujson.loads(d.text)['datetime'][11:13])
        m = int(ujson.loads(d.text)['datetime'][14:16])
        oled.text(date, 0, 0)
        oled.text(times, 0, 10)
        print(date, "|", times)
        hP = int((h % n))
        mP = int((m / (60 / n) % n))
        print("hp:{}, mp:{}".format(hP, mP))
        hColor = (255, 0, 50)
        mColor = (50, 0, 255)
        clear()
        np[mP] = mColor
        np[hP] = hColor
        np.write()

def dht1x():
    global jsondatas
    try:
        dht11.measure()
    except Exception as e:
        print(e)
    temp = dht11.temperature()
    humi = dht11.humidity()
    print("t:{}, h:{}".format(temp, humi))
    time.sleep(2)
    oled.fill(0)
    oled.text("T:" + str(temp) + "*C", 0, 30)
    oled.text("H:" + str(humi) + ".%", 0, 40)
    date_and_time()
    weather_icon()
    oled.show()


def imgs(imgPath):
    img = open(imgPath, "rb")
    img.readline()
    t = img.readline()
    x = int(t.split()[0])
    y = int(t.split()[1])
    iconNum = bytearray(img.read())
    convert = framebuf.FrameBuffer(iconNum, x, y, framebuf.MONO_HLSB)
    img.close()
    return convert
#ADC&PWM
p=ADC(Pin(32))
p.atten(ADC.ATTN_11DB)
ADC.width(ADC.WIDTH_10BIT)
#類似於c裡面的map()函式
def scale_value(value, in_min, in_max, out_min, out_max):
  scaled_value = (value - in_min) * (out_max - out_min) / (in_max - in_min) + out_min
  return scaled_value

# 建立中斷irq
pressState = False
irqPin = 0

def interrupt_irq(pin):
    global irqPin, pressState
    pressState = True
    irqPin = int(str(pin)[4:-1])

def callback(topic, msg):
    #print(topic, msg)
    global n, p, np
    if topic==colorTopic:
        colorVal=msg.decode()
        colorDist=eval(colorVal)
        r=colorDist['r']
        g=colorDist['g']
        b=colorDist['b']
        clear()
        for i in range(n):
            np[i] = (r, g, b)
            np.write()
    if topic==alldayTopic:
        print(msg.decode())
        clear()
        for j in range(0,10):
            for i in range(n):
                np[i] = (50, 30, 200)
                np.write()
                time.sleep_ms(20)
                clear()
            print(j)
            


def connMQTT():
    try:
        client=MQTTClient(server_id, mqtt_server)
        client.set_callback(callback)
        client.connect()
        client.subscribe(alldayTopic)
        client.subscribe(colorTopic)
        print("connect to %s" % mqtt_server)
        return client
    except:
        print("not to connected for MQTT server!")
        machine.reset()


# 板子上的按鍵和LED
led = Pin(2, Pin.OUT)
btn1 = Pin(34, Pin.IN, Pin.PULL_UP)
btn2 = Pin(36, Pin.IN, Pin.PULL_UP)
btn3 = Pin(35, Pin.IN, Pin.PULL_UP)
btn1.irq(trigger=Pin.IRQ_FALLING, handler=interrupt_irq)
btn2.irq(trigger=Pin.IRQ_FALLING, handler=interrupt_irq)
btn3.irq(trigger=Pin.IRQ_FALLING, handler=interrupt_irq)
# DHT11/12
dht11 = dht.DHT11(Pin(13))
client=connMQTT()
while True:
    date_and_time()
    dht1x()
    client.check_msg()
    if pressState:
        print(irqPin)
        pressState = False
        while 1:
            if (irqPin == 34):
                oled.fill(0)
                date_and_time()
                dht1x()
            elif (irqPin == 36):
                #clear()
                pwmVal = p.read()
                if pwmVal==0:
                    client.check_msg()
                elif pwmVal>10 and pwmVal<40:
                    clear()
                elif pwmVal>40 and pwmVal<255:
                    clear()
                    for i in range(0,3):
                        np[i]=(100,40,150)
                        np.write()
                elif pwmVal>255 and pwmVal<510:
                    clear()
                    for i in range(0,6):
                        np[i]=(20,100,150)
                        np.write()
                elif pwmVal>510 and pwmVal<765:
                    clear()
                    for i in range(0,9):
                        np[i]=(0,10,150)
                        np.write()
                elif pwmVal>765:
                    clear()
                    for i in range(0,12):
                        np[i]=(200,10,50)
                        np.write()

                print(pwmVal)
                oled.text("vaule: " + str(pwmVal), 10, 0)
                oled.show()
                oled.rect(10, 30, 90, 20, 1)  # draw a rectangle outline 10,10 to 117,53, colour=1
                oled.fill_rect(10, 30, int(scale_value(pwmVal, 0, 680, 0, 60)), 20,
                                  1)  # draw a solid rectangle 10,10 to 117,53, colour=1
                oled.show()
                oled.fill(0)
                time.sleep(1)
                oled.text("RGB Neopixls!", 10, 20)
                oled.show()
            elif (irqPin == 35):
                date_and_time()
                oled.fill(0)
                oled.blit(imgs("imgs/py.pbm"), 50, 0)
                oled.text("Micropython", 20, 40)
                oled.text("project", 35, 50)
                oled.show()
